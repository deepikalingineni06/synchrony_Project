package com.example.imageUpDown;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImageUpDownApplicationTests {

	@Test
	void contextLoads() {
	}

}
