package com.example.imageUpDown.model;

public class ImageIdObject {

    private Long id;

    public ImageIdObject() {
    }

    public ImageIdObject(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
}
